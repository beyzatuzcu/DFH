# Digital Fraud Hub — Final GitHub Pages Demo

GitHub Pages üzerinde doğrudan çalışan statik fraud erken uyarı demosudur.

## Özellikler
- GDELT açık haber akışından canlı haber taraması
- GDELT Context yaklaşımı ile plaka geçen metin parçalarını önceliklendirme
- Türkiye plaka formatı çıkarımı
- Risk anahtar kelimeleri
- LOW / MEDIUM / HIGH / CRITICAL risk skoru
- Poliçe ve hasar CSV eşleştirmesi
- Public demo için sentetik poliçe/hasar verisi
- Tamamen tarayıcı tarafında çalışma
- Node.js / npm / Next.js gerektirmez

## GitHub Pages
Repo kökünde `index.html`, `app.js`, `styles.css` ve `.nojekyll` bulunmalıdır.

GitHub > Settings > Pages:
- Source: Deploy from a branch
- Branch: main
- Folder: /(root)

## Veri güvenliği
Gerçek kurum içi poliçe/hasar servis adresleri veya API anahtarları public GitHub Pages içine konmamalıdır.
CSV yüklemeleri tarayıcı içinde işlenir.

## Plaka davranışı
Uygulama yalnızca API'nin döndürdüğü başlık/context metninde gerçek bir Türkiye plakası varsa gösterir.
Kaynak metinde plaka yoksa `—` gösterir; tahmin üretmez.
